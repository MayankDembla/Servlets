package com.mayank.myscheduler.db;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropUtility {

	private static Properties prop;

	// TO DO : For a time being it is Hard Coded, looking for an alternative.
	private static String FILE_PATH = "C:\\Users\\Developer\\Desktop\\Java\\Java EE Workspace\\myscheduler\\res\\config.properties";

	private PropUtility() {
		// DO NO Instantiate ..
	}

	/**
	 * Method used to Get the Property from the Config.Properties File...
	 * 
	 * @param property
	 * @return
	 * @throws IOException
	 */
	public static String getProperty(String property) throws IOException {

		prop = new Properties();

		InputStream ipstream = new FileInputStream(/*System.getProperty("user.dir") +*/ FILE_PATH);

		try {
			prop.load(ipstream);
		} catch (FileNotFoundException exp) {
			throw new FileNotFoundException("Property File '" + FILE_PATH + "' not Found in the res Directory !! ");
		}

		return prop.getProperty(property);
	}
}
