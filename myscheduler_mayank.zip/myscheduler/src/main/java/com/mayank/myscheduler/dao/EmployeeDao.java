package com.mayank.myscheduler.dao;

import java.sql.SQLException;
import java.util.List;

import com.mayank.myscheduler.model.Employee;

public interface EmployeeDao {
	
	void initdb() throws SQLException ;
	
	int addEmployee(Employee emp) throws SQLException ; 
	
    List<Employee> showAllEmployee() throws SQLException ;
    
     Employee searchUser(String uname , String pass) throws SQLException; 
    
     boolean isUserExist(String userName, String pass) throws SQLException  ; 
}
