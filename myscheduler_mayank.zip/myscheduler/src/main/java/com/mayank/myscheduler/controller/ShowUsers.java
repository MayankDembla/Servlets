package com.mayank.myscheduler.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mayank.myscheduler.dao.EmployeeDao;
import com.mayank.myscheduler.dao.EmployeeDaoImpl;
import com.mayank.myscheduler.model.Employee;

/**
 * Servlet implementation class ShowUsers
 */
@WebServlet("/ShowUsers")
public class ShowUsers extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private EmployeeDao dao; 
       
    /**
     * @throws SQLException 
     * @see HttpServlet#HttpServlet()
     */
    public ShowUsers() throws SQLException {
        super();
        dao = new EmployeeDaoImpl() ; 
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		List<Employee> list = new ArrayList<Employee>() ; 
		RequestDispatcher rd = getServletContext().getRequestDispatcher("/Showusers.jsp");
		
		try {
			list = dao.showAllEmployee() ;
			request.setAttribute("list", list);
			rd.forward(request, response);
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		
	}
}
