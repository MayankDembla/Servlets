package com.mayank.myscheduler.db;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DbUtility {

	private Connection conn;
	
	public DbUtility() throws SQLException {   
		try {

			Class.forName("com.mysql.jdbc.Driver");
			
			conn =	DataSource.INSTANCE.getConnection(PropUtility.getProperty("db.url") + "/" +  PropUtility.getProperty("db.name"),
					PropUtility.getProperty("db.user"), PropUtility.getProperty("db.password")) ;
		
		} catch (ClassNotFoundException exp) {
			exp.getStackTrace();
		} catch (SQLException ex) {
			ex.getStackTrace();
		} catch (IOException io) {
			io.getStackTrace();
		}
	} // end of Constructor

	

	/**
	 * Method used to Test the Connection
	 * 
	 * @return
	 */
	public boolean testConnection() {
		return ((conn == null) ? false : true);
	}

	/**
	 * Method used to Create the Prepare Statement
	 * 
	 * @param sql
	 * @return
	 * @throws SQLException
	 */
	public PreparedStatement createPstmt(String sql) throws SQLException {
		return conn.prepareStatement(sql);
	}

	/**
	 * MEthod used to perform the Prepare the Update of QUery
	 * 
	 * @param stmt
	 * @return
	 * @throws SQLException
	 */
	public int update(PreparedStatement stmt) throws SQLException {
		return stmt.executeUpdate();
	}

	/**
	 * Method used to execute the Query and return its resultSet
	 * 
	 * @param stmt
	 * @return
	 * @throws SQLException
	 */
	public ResultSet query(PreparedStatement stmt) throws SQLException {
		return stmt.executeQuery();
	}
}
