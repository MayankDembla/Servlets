package com.mayank.myscheduler.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Singleton class for Connection Object
 * @author Developer
 *
 */
public enum DataSource {

	INSTANCE();

	Connection conn;

	public Connection getConnection(String url, String user, String password) throws SQLException {
		return DriverManager.getConnection(url, user, password);
	}
}
