package com.mayank.myscheduler.test;

import java.sql.SQLException;

import com.mayank.myscheduler.db.DbUtility;

public class Test {

	public static void main(String[] args) throws SQLException {
		DbUtility db = new DbUtility() ; 
		System.out.println("Connection is  : " + db.testConnection()) ;  
	}
}
