package com.mayank.crud.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.mayank.crud.dao.EmployeeDao;
import com.mayank.crud.dao.EmployeeDaoImpl;
import com.mayank.crud.model.Employee;

@WebServlet(name = "SaveEmpServlet", urlPatterns = { "/ses" })
public class SaveEmpServlet extends HttpServlet {

	/**
	 * Serialized ID
	 */
	private static final long serialVersionUID = 1L;

	private EmployeeDao dao;

	public SaveEmpServlet() throws SQLException {
		dao = new EmployeeDaoImpl();
	}

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse rsp) throws IOException {
		rsp.setContentType("text/html");
		Employee emp = new Employee();
		PrintWriter out = rsp.getWriter();

		String uname = req.getParameter("uname");

		try {
			if (!dao.isUserExist(uname)) {
				
				if (isNull(req.getParameter("name")) || isNull((req.getParameter("pass")))
						|| isNull(req.getParameter("phoneno")) || isNull(req.getParameter("email"))
						|| isNull(req.getParameter("status")) || isNull(req.getParameter("role"))) {
					rsp.sendRedirect("register.jsp?msg=8");
				}
				
				emp.setLoginName(uname);
				emp.setName(req.getParameter("name"));
				emp.setPass(req.getParameter("pass"));
				emp.setMobNo(Long.valueOf(req.getParameter("phoneno")));
				emp.setEmail(req.getParameter("email"));
				emp.setStatus(Integer.parseInt(req.getParameter("status")));
				emp.setRole(Integer.parseInt(req.getParameter("role")));

				
			    if(dao.addEmployee(emp) > 0) {
					rsp.sendRedirect("Home.jsp?msg=1");
				} else {
					rsp.sendRedirect("register.jsp?msg=7");
				}

			} else {
				// User Already Exist
				if(isNull(uname))
					rsp.sendRedirect("register.jsp?msg=8");
				else
					rsp.sendRedirect("register.jsp?msg=0");
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
			rsp.sendRedirect("register.jsp?msg=7");
		}
	}

	/**
	 * @param data
	 * @return
	 */
	private boolean isNull(String data) {
		if (data.equals("") || data == null)
			return true;

		return false;
	}
}
