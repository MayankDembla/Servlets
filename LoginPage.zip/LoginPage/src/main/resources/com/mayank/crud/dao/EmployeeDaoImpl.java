package com.mayank.crud.dao;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.mayank.crud.db.DbUtility;
import com.mayank.crud.db.PropUtility;
import com.mayank.crud.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	DbUtility db;

	public EmployeeDaoImpl() throws SQLException {
		db = DbUtility.getInstance();
		initdb();
	}

	@Override
	public void initdb() throws SQLException {

		try {
			String createTable = "CREATE TABLE " + PropUtility.getProperty("db.emp")
					+ " ( empid INT AUTO_INCREMENT, name VARCHAR(100), uname VARCHAR(100) NOT NULL UNIQUE, pass VARCHAR(100),mobile BIGINT, email VARCHAR(100) , status TINYINT , role TINYINT , PRIMARY KEY (empid) ) ";

			db.update(db.createPstmt(createTable));
		} catch (SQLException exp) {
			if (exp.getErrorCode() != 1050) // Table is Created Already
				exp.getMessage();
		} catch (IOException e) {
			e.getMessage();
		}

	}

	@Override
	public int addEmployee(Employee emp) throws SQLException {

		String query = null;

		try {
			query = "INSERT INTO " + PropUtility.getProperty("db.emp")
					+ " (name,uname,pass,mobile,email,status,role) VALUES (?,?,?,?,?,?,?)";
		} catch (IOException e) {
			e.printStackTrace();
		}

		PreparedStatement pst = db.createPstmt(query);
		pst.setString(1, emp.getName());
		pst.setString(2, emp.getLoginName());
		pst.setString(3, emp.getPass());
		pst.setLong(4, emp.getMobNo());
		pst.setString(5, emp.getEmail());
		pst.setInt(6, emp.getStatus());
		pst.setInt(7, emp.getRole());

		return db.update(pst);
	}

	@Override
	public List<Employee> showAllEmployee() throws SQLException {

		List<Employee> empl = new ArrayList<Employee>();
		String query = null;

		try {
			query = "Select * from " + PropUtility.getProperty("db.emp");
		} catch (IOException exp) {
			exp.getStackTrace();
		}

		ResultSet rs = db.query(db.createPstmt(query));

		while (rs.next()) {
			Employee emp = new Employee();
			emp.setId(rs.getInt("empid"));
			emp.setName(rs.getString("name"));
			emp.setLoginName(rs.getString("uname"));
			emp.setPass(rs.getString("pass"));
			emp.setMobNo(rs.getLong("mobile"));
			emp.setEmail(rs.getString("email"));
			emp.setStatus(rs.getInt("status"));
			emp.setRole(rs.getInt("role"));
			empl.add(emp);
		}

		return empl;
	}

	@Override
	public Employee searchUser(String uname, String pass) throws SQLException {
		String query = null;

		try {
			query = "Select * from " + PropUtility.getProperty("db.emp") + " Where uname = '" + uname + "' and pass = '"
					+ pass + "';";
		} catch (IOException e) {
			e.printStackTrace();
		}

		ResultSet rs = db.query(db.createPstmt(query));

		rs.next();

		Employee emp = new Employee();
		emp.setId(rs.getInt("empid"));
		emp.setName(rs.getString("name"));
		emp.setLoginName(rs.getString("uname"));
		emp.setPass(rs.getString("pass"));
		emp.setMobNo(rs.getLong("mobile"));
		emp.setEmail(rs.getString("email"));
		emp.setStatus(rs.getInt("status"));
		emp.setRole(rs.getInt("role"));
		
		
		return emp ; 
	}
	
	@Override
	public boolean isUserExist(String userName) throws SQLException 
	{
		
		if(userName == null || userName.equals(""))
			 return true ; 
		
		try {
			String query = "Select uname from " + PropUtility.getProperty("db.emp") + " Where uname = '" + userName + "';" ;
			
			PreparedStatement  pst = db.createPstmt(query) ; 
			ResultSet rs = db.query(pst) ; 
			
			if (!rs.next() ) {
			    return false ;    // return false if no user present 
			} 
		} catch (IOException e) {
			e.printStackTrace();
		} 
		
		return true;
	}

}
