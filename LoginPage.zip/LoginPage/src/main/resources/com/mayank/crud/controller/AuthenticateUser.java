package com.mayank.crud.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.mayank.crud.dao.EmployeeDao;
import com.mayank.crud.dao.EmployeeDaoImpl;
import com.mayank.crud.model.Employee;

@WebServlet(name = "AuthenticateUser", urlPatterns = { "/aut" })
public class AuthenticateUser extends HttpServlet {

	EmployeeDao dao;

	public AuthenticateUser() throws SQLException {
		dao = new EmployeeDaoImpl();
	}

	/**
	 * Serialized ID
	 */
	private static final long serialVersionUID = 102831973239L;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse rsp) throws IOException {

		String uname = req.getParameter("uname");
		HttpSession session = req.getSession(true);
		String pass = req.getParameter("pass");
		try {
			if (!dao.isUserExist(uname)) {

				Employee emp = dao.searchUser(uname, pass);

				if (emp.getRole() == 0) {
					session.setAttribute("user", emp);
					rsp.sendRedirect("User.jsp");
				} else {

				}
			} else {
				rsp.sendRedirect("Home.jsp?msg=3");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}
