package com.mayank.scheduler.dao;

import java.sql.SQLException;
import java.util.List;

import com.mayank.scheduler.model.Appointment;

public interface AppointmentDao {
	public int registerAppointment(Appointment ap) throws SQLException;
	public List<Appointment> getAppointmentByDocId(int id) throws SQLException;
	public List<Appointment> getAllAppointments () throws SQLException;
	public List<Appointment> getAllAppointmentByPid(int id) throws SQLException;


}
