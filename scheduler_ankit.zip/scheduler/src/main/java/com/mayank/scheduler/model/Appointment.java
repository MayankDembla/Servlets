package com.mayank.scheduler.model;

public class Appointment {
	public int aid;
	public int pid;
	public int did;
	public String criticality;
	public String datetime;
	public int getAid() {
		return aid;
	}
	public int getPid() {
		return pid;
	}
	public int getDid() {
		return did;
	}
	public String getCriticality() {
		return criticality;
	}
	public String getDatetime() {
		return datetime;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public void setDid(int did) {
		this.did = did;
	}
	public void setCriticality(String criticality) {
		this.criticality = criticality;
	}
	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}
}