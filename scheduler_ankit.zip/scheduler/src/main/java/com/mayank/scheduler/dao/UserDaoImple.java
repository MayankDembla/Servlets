package com.mayank.scheduler.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mayank.scheduler.db.DBUtility;
import com.mayank.scheduler.model.Users;

public class UserDaoImple implements UserDao{
	PreparedStatement p;
	DBUtility db = new DBUtility();
	public int registerUser(Users u) throws SQLException {
		String sql = "insert into users (username,password,role,criticality) values (?,?,?,?)";
		p =  db.createPST(sql);
		p.setString(1, u.getUsername());
		p.setString(2, u.getPassword());
		p.setString(4, u.getCriticality());
		p.setInt(3, u.getRole());
		return db.updatePst(p);
	}

	public Users getUserById(int id) throws SQLException {
		String sql = "select * from users where id=?";
		p = db.createPST(sql);
		p.setInt(1, id);
		ResultSet rs = db.getResultSet(p);
		Users u  = new Users();
		while(rs.next())
		{
			u.setId(rs.getInt("id"));
			u.setUsername(rs.getString("username"));
			u.setPassword(rs.getString("password"));
			u.setCriticality(rs.getString("criticality"));
			u.setRole(rs.getInt("role"));
		}

		return u;

	}

	public Users getUserByUsername(String username) throws SQLException {
		String sql = "select * from users where username=?";
		p = db.createPST(sql);
		p.setString(1, username);
		ResultSet rs = db.getResultSet(p);
		Users u  = new Users();
		while(rs.next())
		{
			u.setId(rs.getInt("id"));
			u.setUsername(rs.getString("username"));
			u.setPassword(rs.getString("password"));
			u.setCriticality(rs.getString("criticality"));
			u.setRole(rs.getInt("role"));
		}

		return u;

	}

	public List<Users> getUserByRole(int role) throws SQLException {
		String sql = "select * from users where role=?";
		p = db.createPST(sql);
		p.setInt(1, role);
		ResultSet rs = db.getResultSet(p);
		List<Users> ls = new ArrayList<Users>();
		while(rs.next())
		{
			Users u  = new Users();
			u.setId(rs.getInt("id"));
			u.setUsername(rs.getString("username"));
			u.setPassword(rs.getString("password"));
			u.setCriticality(rs.getString("criticality"));
			u.setRole(rs.getInt("role"));
			ls.add(u);
		}

		return ls;

	}

	public List<Users> getUserBySpeciality(String sp) throws SQLException {
		String sql = "select * from users where criticality=?";
		p = db.createPST(sql);
		p.setString(1, sp);
		ResultSet rs = db.getResultSet(p);
		List<Users> ls = new ArrayList<Users>();
		while(rs.next())
		{
			Users u  = new Users();
			u.setId(rs.getInt("id"));
			u.setUsername(rs.getString("username"));
			u.setPassword(rs.getString("password"));
			u.setCriticality(rs.getString("criticality"));
			u.setRole(rs.getInt("role"));
			ls.add(u);
		}

		return ls;
	}

}
