package com.mayank.scheduler.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mayank.scheduler.dao.AppointmentDao;
import com.mayank.scheduler.dao.AppointmentDaoImple;
import com.mayank.scheduler.dao.UserDao;
import com.mayank.scheduler.dao.UserDaoImple;
import com.mayank.scheduler.model.Appointment;
import com.mayank.scheduler.model.Users;

/**
 * Servlet implementation class Showusers
 */
public class Showusers extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int role = Integer.parseInt(request.getParameter("role"));

		if (role != 0 && role!=7) {
			List<Users> ls = new ArrayList<Users>();
			RequestDispatcher rd = getServletContext().getRequestDispatcher("/showusers.jsp?role=" + role);

			UserDao udao = new UserDaoImple();
			try {
				ls = udao.getUserByRole(role);
				request.setAttribute("list", ls);
				rd.forward(request, response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		else if(role==0) {
			List<Appointment> ls = new ArrayList<Appointment>();
			RequestDispatcher rd = getServletContext().getRequestDispatcher("/showusers.jsp?role=" + role);

			AppointmentDao adao = new AppointmentDaoImple();
			try {
				ls = adao.getAllAppointments();
				request.setAttribute("list", ls);
				rd.forward(request, response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			List<Appointment> ls = new ArrayList<Appointment>();
			RequestDispatcher rd = getServletContext().getRequestDispatcher("/showusers.jsp?role=" + role);

			AppointmentDao adao = new AppointmentDaoImple();
			try {
				ls = adao.getAllAppointmentByPid(Integer.parseInt(request.getParameter("id")));
				request.setAttribute("list", ls);
				rd.forward(request, response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
