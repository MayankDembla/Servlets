package com.mayank.scheduler.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBUtility {
	public static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/appointment";
	public static final String USER = "root";
	public static final String PASS = "root";

	private static Connection con;


	private static Connection getConnection()
	{
		if(con==null)
		{
			// STEP 2: Register JDBC driver
			try {
				Class.forName(JDBC_DRIVER).newInstance();
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// STEP 3: Open a connection
			try {
				con = (DriverManager.getConnection(DB_URL, USER, PASS));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return con;
		}
		else
		{
			return con;
		}
	}
	/**
	 * This API is used to prepare the object for prepareStatement.
	 *
	 * @param sql
	 * @return
	 */
	public PreparedStatement createPST(String sql) throws SQLException {
		return DBUtility.getConnection().prepareStatement(sql);
	}

	public int updatePst(PreparedStatement p) {
		int result = 0;
		try {
			result = p.executeUpdate();
		} catch (SQLException e) {
			System.out.println(
					"database access error occurs this method is called on a closed PreparedStatement or the SQL statement returns a ResultSet object .");
			e.printStackTrace();
		}
		return result;
	}

	public ResultSet getResultSet(PreparedStatement p) {
		ResultSet r = null;
		try {
			r = p.executeQuery();
		} catch (SQLException e) {
			System.out.println(
					"database access error occurs this method is called on a closed PreparedStatement or the SQL statement returns a ResultSet object .");
			e.printStackTrace();
		}
		return r;
	}
	public void clearConnection() throws SQLException
	{
		con.close();
	}

}
