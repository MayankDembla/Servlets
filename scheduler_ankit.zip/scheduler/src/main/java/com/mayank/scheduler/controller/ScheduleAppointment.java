package com.mayank.scheduler.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mayank.scheduler.dao.AppointmentDao;
import com.mayank.scheduler.dao.AppointmentDaoImple;
import com.mayank.scheduler.dao.UserDao;
import com.mayank.scheduler.dao.UserDaoImple;
import com.mayank.scheduler.model.Appointment;
import com.mayank.scheduler.model.Users;
import com.mayank.scheduler.services.AppointmentServices;

/**
 * Servlet implementation class ScheduleAppointment
 */
public class ScheduleAppointment extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public ScheduleAppointment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String msg;
		AppointmentDao adao = new AppointmentDaoImple();
		UserDao udao = new UserDaoImple();
		Appointment a = new Appointment();
		List<Appointment> la = new ArrayList<Appointment>();
		AppointmentServices as = new AppointmentServices();

		msg = as.isValidDate(request.getParameter("datetime"))?null:"scheduleappointment.jsp?msg=6";
		if(msg!=null)
			response.sendRedirect(msg);
		Users u = new Users();
		List<Users> ls = new ArrayList<Users>();

		try {

			ls = udao.getUserBySpeciality(request.getParameter("speciality"));
			if(ls.isEmpty())
			{
				msg = "home.jsp?msg=4";
			}else
			{
				for(Users us : ls)
				{
					la = adao.getAppointmentByDocId(us.getId());
					if(la.isEmpty())
					{
						a.setCriticality(us.getCriticality());
						a.setDatetime(request.getParameter("datetime"));
						a.setDid(us.getId());
						a.setPid(Integer.parseInt(request.getParameter("id")));
						adao.registerAppointment(a);

						msg = "scheduleappointment.jsp?msg=5";
					}
					else
					{
						boolean flag = false;
						for(Appointment ap : la)
						{
							if(as.isValidForAppointment(ap.getDatetime(), request.getParameter("datetime")))
							{
								flag = true;
							}
							else
							{
								flag = false;
							}

						}
						if(flag)
						{
							a.setCriticality(us.getCriticality());
							a.setDatetime(request.getParameter("datetime"));
							a.setDid(us.getId());
							a.setPid(Integer.parseInt(request.getParameter("id")));
							adao.registerAppointment(a);
							msg = "scheduleappointment.jsp?msg=5";
						}else
						msg = "scheduleappointment.jsp?msg=7";
					}

				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.sendRedirect(msg);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
