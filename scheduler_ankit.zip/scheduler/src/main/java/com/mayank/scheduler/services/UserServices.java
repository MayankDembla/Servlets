package com.mayank.scheduler.services;

import java.sql.SQLException;

import com.mayank.scheduler.dao.UserDao;
import com.mayank.scheduler.dao.UserDaoImple;
import com.mayank.scheduler.model.Users;



public class UserServices {
	public boolean isUsernameExists(String user) throws SQLException
	{
		UserDao udao = new UserDaoImple();
		Users u = new Users();
		u = udao.getUserByUsername(user);
		return (u.getId()==0)?true:false;
	}
}
