package com.mayank.scheduler.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mayank.scheduler.db.DBUtility;
import com.mayank.scheduler.model.Appointment;

public class AppointmentDaoImple implements AppointmentDao{
	PreparedStatement p;
	DBUtility db =new DBUtility();
	public int registerAppointment(Appointment ap) throws SQLException {
		String sql = "insert into appointment (did,pid,datetime,criticality) values (?,?,?,?)";
		p = db.createPST(sql);
		p.setInt(1, ap.getDid());
		p.setInt(2, ap.getPid());
		p.setString(3, ap.getDatetime());
		p.setString(4, ap.getCriticality());
		return db.updatePst(p);
	}

	public List<Appointment> getAppointmentByDocId(int id) throws SQLException {
		List<Appointment> ls = new ArrayList<Appointment>();
		String sql = "select * from appointment where did=?";
		p = db.createPST(sql);
		p.setInt(1, id);
		ResultSet rs = db.getResultSet(p);
		while(rs.next())
		{
			Appointment a = new Appointment();
			a.setPid(Integer.parseInt(rs.getString("pid")));
			a.setDid(Integer.parseInt(rs.getString("did")));
			a.setCriticality(rs.getString("criticality"));
			a.setDatetime(rs.getString("datetime"));
			ls.add(a);
		}
		return ls;
	}

	public List<Appointment> getAllAppointments() throws SQLException {
		List<Appointment> ls = new ArrayList<Appointment>();
		String sql = "select * from appointment";
		p = db.createPST(sql);
		ResultSet rs = db.getResultSet(p);
		while(rs.next())
		{
			Appointment a = new Appointment();
			a.setPid(Integer.parseInt(rs.getString("pid")));
			a.setDid(Integer.parseInt(rs.getString("did")));
			a.setCriticality(rs.getString("criticality"));
			a.setDatetime(rs.getString("datetime"));
			ls.add(a);
		}
		return ls;
	}

	public List<Appointment> getAllAppointmentByPid(int id) throws SQLException {
		List<Appointment> ls = new ArrayList<Appointment>();
		String sql = "select * from appointment where pid=?";
		p = db.createPST(sql);
		p.setInt(1, id);
		ResultSet rs = db.getResultSet(p);
		while(rs.next())
		{
			Appointment a = new Appointment();
			a.setPid(Integer.parseInt(rs.getString("pid")));
			a.setDid(Integer.parseInt(rs.getString("did")));
			a.setCriticality(rs.getString("criticality"));
			a.setDatetime(rs.getString("datetime"));
			ls.add(a);
		}
		return ls;
	}

}
