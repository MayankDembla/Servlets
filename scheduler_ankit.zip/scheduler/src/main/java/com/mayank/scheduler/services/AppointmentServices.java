package com.mayank.scheduler.services;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AppointmentServices {

	public boolean isValidDate(String applyDate) {
		// get current date
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Date date = new Date();
		String curDate = dateFormat.format(date).toString().replace(" ", "T");
		boolean flag = false;
		if (isSameYear(curDate, applyDate)) {
			if (isSameMonth(curDate, applyDate)) {
				if (isDaySame(curDate, applyDate)) {
					if (isHoursSame(curDate, applyDate)) {
						if (isMinValid(curDate, applyDate)) {
							flag = true;
						}
					}
					if (isHoursValid(curDate, applyDate)) {
						flag = true;
					}
				}
				if (isDayValid(curDate, applyDate)) {
					flag = true;
				}
			}
			if (isMonthValid(curDate, applyDate)) {
				flag = true;
			}
		}
		if (isYearValid(curDate, applyDate)) {
			flag = true;
		}
		return flag;

	}

	private boolean isSameYear(String curDate, String applyDate) {
		int curYear = Integer.parseInt(curDate.substring(0, 4));
		int appYear = Integer.parseInt(applyDate.substring(0, 4));
		return (appYear == curYear) ? true : false;
	}

	private boolean isSameMonth(String curDate, String applyDate) {
		int curMonth = Integer.parseInt(curDate.substring(5, 7));
		int appMonth = Integer.parseInt(applyDate.substring(5, 7));
		return (appMonth == curMonth) ? true : false;
	}

	private boolean isYearValid(String curDate, String applyDate) {
		int curYear = Integer.parseInt(curDate.substring(0, 4));
		int appYear = Integer.parseInt(applyDate.substring(0, 4));
		return (appYear > curYear) ? true : false;
	}

	private boolean isMonthValid(String curDate, String applyDate) {
		int curMonth = Integer.parseInt(curDate.substring(5, 7));
		int apMonth = Integer.parseInt(applyDate.substring(5, 7));
		return (apMonth >= curMonth) ? true : false;
	}

	private boolean isDayValid(String curDate, String applyDate) {
		int curDay = Integer.parseInt(curDate.substring(8, 10));
		int apDay = Integer.parseInt(applyDate.substring(8, 10));
		return (apDay >= curDay) ? true : false;
	}

	private boolean isDaySame(String curDate, String applyDate) {
		int curDay = Integer.parseInt(curDate.substring(8, 10));
		int apDay = Integer.parseInt(applyDate.substring(8, 10));
		return (apDay == curDay) ? true : false;
	}

	private boolean isHoursValid(String curDate, String applyDate) {
		int curHour = Integer.parseInt(curDate.substring(11, 13));
		int apHour = Integer.parseInt(applyDate.substring(11, 13));
		return (apHour <= curHour) ? true : false;
	}

	private boolean isHoursSame(String curDate, String applyDate) {
		int curHour = Integer.parseInt(curDate.substring(11, 13));
		int apHour = Integer.parseInt(applyDate.substring(11, 13));
		return (apHour == curHour) ? true : false;
	}

	private boolean isMinValid(String curDate, String applyDate) {
		int curMin = Integer.parseInt(curDate.substring(14, 16));
		int apMin = Integer.parseInt(applyDate.substring(14, 16));
		return (apMin > curMin) ? true : false;
	}

	public boolean isValidForAppointment(String curDate, String applyDate) {
		boolean flag = false;
		if (!curDate.equalsIgnoreCase(applyDate))
		{
			flag = true;
		}
		return flag;
	}
}