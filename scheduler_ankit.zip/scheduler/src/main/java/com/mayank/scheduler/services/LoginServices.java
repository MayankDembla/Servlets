package com.mayank.scheduler.services;

import java.sql.SQLException;

import com.mayank.scheduler.dao.UserDao;
import com.mayank.scheduler.dao.UserDaoImple;
import com.mayank.scheduler.model.Users;

public class LoginServices
{
	public boolean isCredentialMatching(String username, String password) throws SQLException
	{
		UserDao udao = new UserDaoImple();
		Users u = new Users();
		u = udao.getUserByUsername(username);
		return (password.equalsIgnoreCase(u.getPassword()))?true:false;

	}
}
