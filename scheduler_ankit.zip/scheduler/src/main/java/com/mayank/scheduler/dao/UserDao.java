package com.mayank.scheduler.dao;

import java.sql.SQLException;
import java.util.List;

import com.mayank.scheduler.model.Users;

public interface UserDao
{
	public int registerUser(Users u) throws SQLException;
	public Users getUserById(int id) throws SQLException;
	public Users getUserByUsername(String username) throws SQLException;
	public List<Users> getUserByRole(int role) throws SQLException;
	public List<Users> getUserBySpeciality(String sp) throws SQLException;
}
