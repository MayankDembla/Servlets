package com.mayank.scheduler.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mayank.scheduler.dao.UserDao;
import com.mayank.scheduler.dao.UserDaoImple;
import com.mayank.scheduler.model.Users;
import com.mayank.scheduler.services.LoginServices;

/**
 * Servlet implementation class Login
 */
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		LoginServices ls = new LoginServices();
		UserDao udao = new UserDaoImple();
		RequestDispatcher rd;
		try {
			if(ls.isCredentialMatching(request.getParameter("username"), request.getParameter("password")))
			{
				HttpSession session = request.getSession(true);
				//set session
				Users u  = new Users();
				u = udao.getUserByUsername(request.getParameter("username"));
				session.setAttribute("user", u);
				response.sendRedirect("home.jsp");
			}
			else
			{
				response.sendRedirect("index.jsp?msg=3");

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**77
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
