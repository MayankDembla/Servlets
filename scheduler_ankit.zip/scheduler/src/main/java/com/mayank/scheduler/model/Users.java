package com.mayank.scheduler.model;

public class Users {
	public int id;

	public int role;
	public String username;
	public String password;
String criticality;
public int getId() {
	return id;
}

public int getRole() {
	return role;
}
public String getUsername() {
	return username;
}
public String getCriticality() {
	return criticality;
}
public String getPassword() {
	return password;
}
public void setId(int id) {
	this.id = id;
}

public void setRole(int role) {
	this.role = role;
}
public void setUsername(String username) {
	this.username = username;
}
public void setCriticality(String criticality) {
	this.criticality = criticality;
}
public void setPassword(String password) {
	this.password = password;
}
}
